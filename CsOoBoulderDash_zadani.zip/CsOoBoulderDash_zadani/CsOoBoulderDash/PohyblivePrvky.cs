﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace CsOoBoulderDash
{

    abstract class PohyblivyPrvek : Prvek
    {
        protected Mapa mapa;

        public void NastavMapu(Mapa mapa)
        {
            this.mapa = mapa;
        }

        public bool JeAktivniNaMape = false;

        public int Smer;

        public int X => mapa.VratX(this);

        public int Y => mapa.VratY(this);

        public abstract void UdelejKrok();
    }

    class Hrdina : PohyblivyPrvek
    {
        protected override int VratIndexZakladnihoObrazku() => 2;

        public override void UdelejKrok()
        {
            int zmenaX = 0;
            int zmenaY = 0;

            // ###########################################################

            switch (mapa.StisknutaSipka)
            {
                case Sipka.Zadna:
                    break;
                case Sipka.Doprava:
                    // ...tady neco schazi...
                    break;
                case Sipka.Doleva:
                    // ...tady neco schazi...
                    break;
                case Sipka.Nahoru:
                    // ...tady neco schazi..
                    break;
                case Sipka.Dolu:
                    // ...tady neco schazi...
                    break;
                default:
                    break;
            }

            // ###########################################################

            int noveX = X + zmenaX;
            int noveY = Y + zmenaY;

            if (mapa.JeVolnoNeboHlina(noveX, noveY))
            {
                mapa.PresunNa(this, noveX, noveY);     // Vraci zruseny prvek, ten si muzeme ulozit pro dalsi prozkoumani: Prvek zrusenyPrvek = mapa.PresunNa(this, noveX, noveY);
            }
        }
    }

    class Balvan : PohyblivyPrvek
    {
        protected override int VratIndexZakladnihoObrazku() => 3;

        public override void UdelejKrok()
        {
            // ###########################################################
            // ...tady neco schazi...
            // ###########################################################
        }
    }

    class Diamant : Balvan
    {
        protected override int VratIndexZakladnihoObrazku() => 9;

        public override void UdelejKrok()
        {
            // ###########################################################
            // ...tady neco schazi...
            // ###########################################################
        }
    }

    class Prisera : PohyblivyPrvek
    {
        protected override int VratIndexZakladnihoObrazku() => 4 + Smer * VratPocetKrokuAnimace();

        public override void UdelejKrok()
        {
            // ###########################################################
            // ...tady neco schazi...
            // ###########################################################
        }
    }

}