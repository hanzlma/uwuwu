﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace CsOoBoulderDash
{

    abstract class Prvek
    {
        protected abstract int VratIndexZakladnihoObrazku();

        public virtual int VratPocetKrokuAnimace() => 1;

        public virtual int VratIndexAktualnihoObrazku()
        {
            int index = VratIndexZakladnihoObrazku();

            // ###########################################################
            // ...tady neco schazi...
            // ###########################################################

            return index;
        }
    }

    class Hlina : Prvek
    {
        public static readonly Hlina Obycejna = new Hlina();

        protected override int VratIndexZakladnihoObrazku() => 1;
    }

    class Zed : Prvek
    {
        public static readonly Zed Obycejna = new Zed();

        protected override int VratIndexZakladnihoObrazku() => 8;
    }

    class Vychod : Prvek
    {
        protected override int VratIndexZakladnihoObrazku() {
            int index = 10;
            if (JeOtevreny)
            {
                index += 1;
            }
            return index;
        }

        public bool JeOtevreny = false;
    }

}