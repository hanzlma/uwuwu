﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CsOoBoulderDash
{
    partial class MapovyControl : Control
    {
        public Mapa AktualniMapa = null;

        public MapovyControl()
        {
            InitializeComponent();

            // Standardni posloupnost prikazu, aby prvek neblikal pri prekreslovani:
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);

            // Chceme, aby se prvek automaticky cely komplet prekreslil pri zmene velikosti:
            SetStyle(ControlStyles.ResizeRedraw, true);
        }

        private Brush prekryvaciStetecVyhra = new SolidBrush(Color.FromArgb(60, Color.Lime));
        private Brush prekryvaciStetecProhra = new SolidBrush(Color.FromArgb(60, Color.Red));

        protected override void OnPaint(PaintEventArgs pe)
        {
            Graphics g = pe.Graphics;
            g.Clear(Color.White);
            if (AktualniMapa != null)
            {
                AktualniMapa.VykresliSe(g, Width, Height);

                if (AktualniMapa.Stav != StavHry.Bezi)
                {
                    Brush stetec = null;
                    if (AktualniMapa.Stav == StavHry.Vyhra)
                    {
                        stetec = prekryvaciStetecVyhra;
                    } else if (AktualniMapa.Stav == StavHry.Prohra)
                    {
                        stetec = prekryvaciStetecProhra;
                    }

                    if (stetec != null) {
                        g.FillRectangle(stetec, 0, 0, Width, Height);
                    }
                }
            }
        }
    }
}
