﻿
namespace CsOoBoulderDash
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.startHryButton = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.mapovyControl1 = new CsOoBoulderDash.MapovyControl();
            this.SuspendLayout();
            // 
            // startHryButton
            // 
            this.startHryButton.Location = new System.Drawing.Point(12, 12);
            this.startHryButton.Name = "startHryButton";
            this.startHryButton.Size = new System.Drawing.Size(118, 23);
            this.startHryButton.TabIndex = 0;
            this.startHryButton.Text = "Start nové hry";
            this.startHryButton.UseVisualStyleBackColor = true;
            this.startHryButton.Click += new System.EventHandler(this.startHryButton_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // mapovyControl1
            // 
            this.mapovyControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mapovyControl1.Location = new System.Drawing.Point(12, 41);
            this.mapovyControl1.Name = "mapovyControl1";
            this.mapovyControl1.Size = new System.Drawing.Size(1021, 605);
            this.mapovyControl1.TabIndex = 1;
            this.mapovyControl1.Text = "mapovyControl1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1045, 658);
            this.Controls.Add(this.mapovyControl1);
            this.Controls.Add(this.startHryButton);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button startHryButton;
        private MapovyControl mapovyControl1;
        private System.Windows.Forms.Timer timer1;
    }
}

