﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CsOoBoulderDash
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            Text = VratPopisStavuHry();
        }

        Sipka stisknutaSipka = Sipka.Zadna;
        Mapa mapa;

        private void startHryButton_Click(object sender, EventArgs e)
        {
            mapa = new Mapa("plan.txt", "obrazky-boulder-dash.png");
            mapovyControl1.AktualniMapa = mapa;
            mapovyControl1.Refresh();

            Text = VratPopisStavuHry();

            stisknutaSipka = Sipka.Zadna;
            timer1.Enabled = true;

            mapa.Stav = StavHry.Bezi;
        }

        private string VratPopisStavuHry()
        {
            string popis = "";

            StavHry stav = StavHry.Nezacala;
            if (mapa != null)
            {
                stav = mapa.Stav;
                popis = $" a zbývá sebrat {mapa.ZbyvaDiamantu} diamantů";
            }

            return $"Hra {stav}" + popis;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Text = VratPopisStavuHry();

            switch (mapa.Stav)
            {
                case StavHry.Bezi:
                    mapa.PohniVsemiPohyblivymiPrvky(stisknutaSipka);
                    mapovyControl1.Refresh();
                    break;
                case StavHry.Vyhra:
                    timer1.Enabled = false;
                    stisknutaSipka = Sipka.Zadna;
                    MessageBox.Show("Vyhra!");
                    break;
                case StavHry.Prohra:
                    timer1.Enabled = false;
                    stisknutaSipka = Sipka.Zadna;
                    MessageBox.Show("Prohra!");
                    break;
                default:
                    break;
            }
        }

        // POZOR - aby nize uvedene fungovalo, je treba, aby mel tento formular nastaveny vlastnost KeyPreview na true (je nastaveno v Navrhu/Designeru)!
        // HACK na odchyceni stisku sipek:
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Up)
            {
                stisknutaSipka = Sipka.Nahoru;
                return true;
            }
            if (keyData == Keys.Down)
            {
                stisknutaSipka = Sipka.Dolu;
                return true;
            }
            if (keyData == Keys.Left)
            {
                stisknutaSipka = Sipka.Doleva;
                return true;
            }
            if (keyData == Keys.Right)
            {
                stisknutaSipka = Sipka.Doprava;
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            base.OnKeyUp(e);
            stisknutaSipka = Sipka.Zadna;
        }
    }
}
