﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace CsOoBoulderDash
{
    enum Sipka { Zadna, Doleva, Nahoru, Doprava, Dolu };

    enum StavHry { Nezacala, Bezi, Vyhra, Prohra };

    class Mapa
    {
        private int sirka;
        private int vyska;
        private Prvek[,] plan;

        private Dictionary<PohyblivyPrvek, Point> pozicePohyblivychPrvku = new Dictionary<PohyblivyPrvek, Point>();     // Pro kazdy pohyblivy prvek na teto mape si pamatujeme jeho X, a Y
        private List<PohyblivyPrvek> rusenePohyblivePrvky = new List<PohyblivyPrvek>();     // Seznam prvku, ktere se maji zrusit z mapy na konci snimku

        private Hrdina hrdina;
        private Vychod vychod;

        private Bitmap[] sprity;
        private int rozmerSpritu;

        public int ZbyvaDiamantu = 0;

        public Sipka StisknutaSipka = Sipka.Zadna;
        public StavHry Stav = StavHry.Nezacala;

        public Mapa(string jmenoSouboruPlanemMapy, string jmenoSouboruSpriteSheetu)
        {
            NactiSprity(jmenoSouboruSpriteSheetu);
            NactiMapu(jmenoSouboruPlanemMapy);
        }

        public int VratX(PohyblivyPrvek pohyblivyPrvek)
        {
            return pozicePohyblivychPrvku[pohyblivyPrvek].X;
        }

        public int VratY(PohyblivyPrvek pohyblivyPrvek)
        {
            return pozicePohyblivychPrvku[pohyblivyPrvek].Y;
        }

        public Prvek PresunMezi(int zdrojoveX, int zdrojoveY, int cilX, int cilY)
        {
            Prvek prvek = plan[zdrojoveX, zdrojoveY];

            if (prvek == null)
            {
                throw new ArgumentException($"Zdrojove pole [{zdrojoveX}, {zdrojoveY}] je prazdne, neni co presunout!");
            }
            if (prvek is PohyblivyPrvek)
            {
                return PresunNa(prvek as PohyblivyPrvek, cilX, cilY);   // Pro pohyblive prvky je treba jeste aktualizovat jejich pozici v seznamu pozic
            } else {
                throw new ArgumentException($"Zdrojove pole [{zdrojoveX}, {zdrojoveY}] obsahuje {prvek.GetType().Name}, a tu neni mozne presouvat!");
            }
        }

        public Prvek PresunNa(PohyblivyPrvek presouvanyPrvek, int cilX, int cilY)
        {
            // Pokud je prvek na mape, tak jeho puvodni pole ma zustat prazdne

            if (presouvanyPrvek.JeAktivniNaMape) {
                plan[presouvanyPrvek.X, presouvanyPrvek.Y] = null;
            }

            // Aktualizuj zapamatovanou pozici pro pohyblivy prvek
            // Pokud zatim zadnou pro tento pohyblivy prvek nemame, tak si uloz novou.

            pozicePohyblivychPrvku[presouvanyPrvek] = new Point(cilX, cilY);

            if (!presouvanyPrvek.JeAktivniNaMape)
            {
                presouvanyPrvek.NastavMapu(this);
                presouvanyPrvek.JeAktivniNaMape = true;
            }

            // Presun prvek na nove misto na planu, a vrat prvek, ktery byl puvodne na cilovem miste.

            Prvek rusenyPrvek = plan[cilX, cilY];
            PohyblivyPrvek rusenyPohyblivyPrvek = rusenyPrvek as PohyblivyPrvek;
            if (rusenyPohyblivyPrvek != null)
            {
                rusenePohyblivePrvky.Add(rusenyPohyblivyPrvek); // Zatim prvek nesmazeme se seznamu, aby se nam nerozbilo prochazeni seznamu v PohniVsemiPohyblivymiPrvky(),
                                                                // ale pouze pridame na seznam rusenych prvku - tyto prvky se zrusi az na uplnem konci PohniVsemiPohyblivymiPrvky().
                rusenyPohyblivyPrvek.JeAktivniNaMape = false;
            }

            plan[cilX, cilY] = presouvanyPrvek;

            return rusenyPrvek;
        }

        public void PohniVsemiPohyblivymiPrvky(Sipka stisknutaSipka)
        {
            this.StisknutaSipka = stisknutaSipka;

            rusenePohyblivePrvky.Clear();

            PohyblivyPrvek[] seznam = pozicePohyblivychPrvku.Keys.ToArray();
            foreach (PohyblivyPrvek p in seznam)
            {
                if (p != hrdina)
                {
                    if (p.JeAktivniNaMape)
                    {
                        p.UdelejKrok();
                    }
                }
            }

            // Krok hrdiny chceme vzdy udelat az posledni:
            if (Stav == StavHry.Bezi && hrdina.JeAktivniNaMape)
            {
                hrdina.UdelejKrok();
            }

            // Pokud vyse uvedena volani *.UdelejKrok() pripravila do seznamu rusenePohyblivePrvky nejake prvky ke smazani,
            // tak je ted smazme:
            foreach (PohyblivyPrvek p in rusenePohyblivePrvky)
            {
                if (p != hrdina)    // Hrdinu potrebujeme pro urceni polohy zobrazeni, i kdyz uz neni aktivni, toho tedy nerusme
                {
                    pozicePohyblivychPrvku.Remove(p);
                    p.NastavMapu(null);
                }
            }
        }

        public bool JeBalvan(int x, int y)
        {
            return plan[x, y] is Balvan; // && !JeDiamant(x, y);    // Dulezite koncepcni rozhodnuti: je kazdy diamant take balvan? Ano = nechame zakomentovane, Ne = odkomentujeme druhou podminku.
        }

        public bool JeDiamant(int x, int y)
        {
            return plan[x, y] is Diamant;
        }

        public bool JeVolno(int x, int y)
        {
            return plan[x, y] == null;
        }

        public bool JeVolnoNeboHlina(int x, int y)
        {
            return JeVolno(x, y) || plan[x, y] is Hlina;
        }

        public bool JeOtevrenyVychod(int x, int y)
        {
            return plan[x, y] is Vychod && (plan[x, y] as Vychod).JeOtevreny;
        }

        public void OtevriVychod()
        {
            vychod.JeOtevreny = true;
        }

        public void VykresliSe(Graphics g, int sirkaVyrezuPixely, int vyskaVyrezuPixely)
        {
            int sirkaVyrezu = sirkaVyrezuPixely / rozmerSpritu;
            int vyskaVyrezu = vyskaVyrezuPixely / rozmerSpritu;

            if (sirkaVyrezu > sirka)
                sirkaVyrezu = sirka;

            if (vyskaVyrezu > vyska)
                vyskaVyrezu = vyska;

            // Urcit LHR vyrezu:
            int dx = hrdina.X - sirkaVyrezu / 2;
            if (dx < 0)
                dx = 0;
            if (dx + sirkaVyrezu - 1 >= this.sirka)
                dx = this.sirka - sirkaVyrezu;

            int dy = hrdina.Y - vyskaVyrezu / 2;
            if (dy < 0)
                dy = 0;
            if (dy + vyskaVyrezu - 1 >= this.vyska)
                dy = this.vyska - vyskaVyrezu;

            for (int x = 0; x < sirkaVyrezu; x++)
            {
                for (int y = 0; y < vyskaVyrezu; y++)
                {
                    int mx = dx + x; // Index do mapy
                    int my = dy + y; // Index do mapy

                    Prvek prvek = plan[mx, my];

                    int indexObrazku = 0;
                    if (prvek != null)
                    {
                        indexObrazku = prvek.VratIndexAktualnihoObrazku();
                    }
                    g.DrawImage(sprity[indexObrazku], x * rozmerSpritu, y * rozmerSpritu);
                }
            }
        }

        public void NactiMapu(string cesta)
        {
            System.IO.StreamReader sr = new System.IO.StreamReader(cesta);
            sirka = int.Parse(sr.ReadLine());
            vyska = int.Parse(sr.ReadLine());
            plan = new Prvek[sirka, vyska];
            ZbyvaDiamantu = 0;

            for (int y = 0; y < vyska; y++)
            {
                string radek = sr.ReadLine();
                for (int x = 0; x < sirka; x++)
                {
                    char znak = radek[x];

                    Prvek prvek = null;
                    // Rozpoznat bezny staticky prvek, nebo pripadne vytvorit pohyblive objekty:
                    switch (znak)
                    {
                        // Pohyblive prvky:
                        case 'H':
                            hrdina = new Hrdina();
                            prvek = hrdina;
                            break;

                        case '<':
                        case '^':
                        case '>':
                        case 'v':
                            Prisera prisera = new Prisera();
                            prisera.Smer = "<^>v".IndexOf(znak);
                            prvek = prisera;
                            break;

                        case 'B':
                            prvek = new Balvan();
                            break;

                        case 'D':
                            prvek = new Diamant();
                            ZbyvaDiamantu++;
                            break;

                        // Staticke prvky:
                        case 'h':
                            prvek = Hlina.Obycejna;
                            break;
                        case 'X':
                            prvek = Zed.Obycejna;
                            break;
                        case 'E':
                            vychod = new Vychod();
                            vychod.JeOtevreny = false;
                            prvek = vychod;
                            break;

                        default:
                            break;
                    }         

                    PohyblivyPrvek pohyblivyPrvek = prvek as PohyblivyPrvek;
                    if (pohyblivyPrvek == null)
                    {   // Je to staticky nepohyblivy prvek:
                        plan[x, y] = prvek;
                    } else
                    {   // Je to pohyblivy prvek:
                        PresunNa(pohyblivyPrvek, x, y);
                    }
                }
            }
            sr.Close();
        }

        public void NactiSprity(string jmenoSouboruSpriteSheetu)
        {
            Bitmap bmp = new Bitmap(jmenoSouboruSpriteSheetu);
            this.rozmerSpritu = bmp.Height;
            int pocet = bmp.Width / rozmerSpritu;   // Predpokladame, ze to je klasicky sprite sheet, tedy ze jsou kosticky poporade v jednom radku
            sprity = new Bitmap[pocet];
            for (int i = 0; i < pocet; i++)
            {
                Rectangle rect = new Rectangle(i * rozmerSpritu, 0, rozmerSpritu, rozmerSpritu);
                sprity[i] = bmp.Clone(rect, System.Drawing.Imaging.PixelFormat.DontCare);
            }
        }
    }
}